create database bankmanagementsystem; 
use bankmanagementsystem;



create table signup(
formno VARCHAR(20) PRIMARY KEY,
name VARCHAR(20) not null,
father_name VARCHAR(20) NOT NULL,
dob varchar(20) NOT NULL,
gender VARCHAR(20) NOT NULL constraint chk_gen CHECK (gender in ('Male','Female')),
email VARCHAR(30) UNIQUE  constraint chk_email CHECK (email like '%@%.com'),
marital_status VARCHAR(20) NOT NULL  constraint chk_mar CHECK (marital_status in ('Married','Unmarried','Other')),
address VARCHAR(40) NOT NULL,
city VARCHAR(20) NOT NULL,
pin_code VARCHAR(20) NOT NULL ,
state VARCHAR(20) NOT NULL
);




create table signuptwo(
formno VARCHAR(20),
religion VARCHAR(20) not null,
contact VARCHAR(20) not null,
income VARCHAR(20) not null,
education VARCHAR(20),
occupation VARCHAR(20),
ntn VARCHAR(20) not null,
cnic VARCHAR(20) not null primary key,
seniorcitizen VARCHAR(20) constraint chk_citi CHECK (seniorcitizen in ('Yes','No')) ,
existingaccount VARCHAR(20)  constraint chk_acc CHECK (existingaccount in ('Yes','No')),
CONSTRAINT fk_sign2 FOREIGN KEY (formno) REFERENCES signup(formno)
);



create table signupthree(
formno varchar(20),
accountType varchar(20) not null,
cardnumber varchar(100) not null,
pin varchar(20) Primary key,
facility varchar(100),
CONSTRAINT fk_sign3 FOREIGN KEY (formno) REFERENCES signup(formno)
);

create table login(
formno varchar(20),
cardnumber varchar(25) not null primary key,
pin varchar(20) not null ,
CONSTRAINT fk_customer FOREIGN KEY (formno) REFERENCES signup(formno),
CONSTRAINT fk_pin FOREIGN KEY (pin) REFERENCES signupthree(pin)
);

create table bank(
pin varchar(20),
date varchar(100),
type varchar(20),
amount varchar(20),
CONSTRAINT fk_bank FOREIGN KEY (pin) REFERENCES signupthree(pin)
);

insert into signup(formno,name,father_name,dob,gender,email,marital_status,address,city,pin_code,state) values('7200','Eisha','Zia','18,july,1994','Female','eishazia@gmail.com','Married','Fatima Golf Residency','Karachi','12909','Sindh');
insert into signuptwo(formno, religion,contact,income,ntn,cnic,seniorcitizen,existingaccount) values 
('7200','Islam','03002036087','150000','4758564720','4210183673493','No','Yes');
insert into signupthree(formno,accountType,cardnumber,pin, facility) values
('7200','saving Account','2675460340475','4245','ATM Card');

delete from signupthree where pin='4245';
drop table signup;
drop table login;
drop table bank;
select * from signup;
select * from signuptwo;
select * from signupthree;
select*from login;
select *from bank;
